'use client'

import { createContext, useContext, useState, useEffect } from 'react'
import { pb } from '../lib/pocketbase'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isAuthReady, setIsAuthReady] = useState(false)

  useEffect(() => {
    setUser(pb.authStore.record || pb.authStore.model)
    setIsAuthenticated(pb.authStore.isValid)
    setIsAuthReady(true)

    // Lắng nghe thay đổi trạng thái đăng nhập từ PocketBase
    const unsubscribe = pb.authStore.onChange((token, model) => {
      setUser(model)
      setIsAuthenticated(pb.authStore.isValid)
      document.cookie = pb.authStore.exportToCookie({ httpOnly: false, path: '/' })
    })

    // Đồng bộ ngay lúc mount để Next.js API route nhận được cookie
    if (typeof document !== 'undefined') {
      document.cookie = pb.authStore.exportToCookie({ httpOnly: false, path: '/' })
    }

    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe()
      }
    }
  }, [])

  const login = async (email, password) => {
    try {
      const authData = await pb.collection('users').authWithPassword(email, password)
      return { success: true, data: authData }
    } catch (err) {
      console.error(err)
      return { success: false, error: err.message || 'Đăng nhập thất bại. Vui lòng kiểm tra lại thông tin.' }
    }
  }

  const register = async (name, email, password, passwordConfirm) => {
    try {
      const data = {
        name,
        email,
        password,
        passwordConfirm,
        role: 'user', // Mặc định role là user khi đăng ký từ web
      }
      // Gửi request tạo tài khoản tới PocketBase
      const record = await pb.collection('users').create(data)
      return { success: true, data: record }
    } catch (err) {
      console.error(err)
      let errorMessage = 'Đăng ký thất bại.'
      // Trích xuất lỗi cụ thể từ PocketBase trả về
      if (err.response?.data) {
        const fieldErrors = Object.entries(err.response.data)
          .map(([field, info]) => `${field}: ${info.message}`)
          .join(' | ')
        if (fieldErrors) {
          errorMessage = fieldErrors
        }
      } else if (err.message) {
        errorMessage = err.message
      }
      return { success: false, error: errorMessage }
    }
  }

  const logout = () => {
    pb.authStore.clear() // Xoá session
    setUser(null)
    setIsAuthenticated(false)
    setIsAuthReady(true)
  }

  const forgotPassphrase = async (email) => {
    try {
      await pb.collection('users').requestPasswordReset(email)
      return { success: true, message: 'Quy trình khôi phục đã được gửi đến địa chỉ email của bạn.' }
    } catch (err) {
      return { success: false, error: err.message || 'Lỗi gửi yêu cầu khôi phục.' }
    }
  }

  // Re-fetch user record từ PocketBase để cập nhật role mới sau khi thanh toán
  const refreshUser = async () => {
    try {
      const userRecord = pb.authStore.record || pb.authStore.model
      if (!pb.authStore.isValid || !userRecord?.id) return
      const freshUser = await pb.collection('users').getOne(userRecord.id)
      // Cập nhật authStore model và state
      pb.authStore.save(pb.authStore.token, freshUser)
      setUser(freshUser)
    } catch (err) {
      console.error('[AuthContext] refreshUser thất bại:', err.message)
    }
  }

  const isPaid = user?.role === 'paid' || user?.role === 'admin'

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, isAuthReady, isPaid, login, register, logout, forgotPassphrase, refreshUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export default AuthContext
